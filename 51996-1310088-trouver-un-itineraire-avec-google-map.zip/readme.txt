Trouver un itin�raire avec google map-------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/51996-trouver-un-itineraire-avec-google-mapAuteur  : amrounixDate    : 07/08/2013
Licence :
=========

Ce document intitul� � Trouver un itin�raire avec google map � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Un petit programme en javascript utilisant l'API Google MAP (version 3) pour tra
cer un itin&eacute;raire entre 2 points. C'est qu'un d&eacute;but, mais on peut 
imaginer beaucoup d'am&eacute;lioration &agrave; ce programme :)
<br /><a name=
'source-exemple'></a><h2> Source / Exemple : </h2>
<br /><pre class='code' dat
a-mode='basic'>
&lt;html&gt; 
&lt;head&gt; 
&lt;meta http-equiv=&quot;content
-type&quot; content=&quot;text/html; charset=UTF-8&quot;/&gt; 
&lt;!--importati
on de l'API google MAP Version 3--&gt;
&lt;script type=&quot;text/javascript&qu
ot; src=&quot;<a href='http://maps.google.com/maps/api/js?sensor=false' target='
_blank'>http://maps.google.com/maps/api/js?sensor=false</a>&quot;&gt;&lt;/script
&gt; 
&lt;script type=&quot;text/javascript&quot;&gt; 
  var directionsService
 = new google.maps.DirectionsService();
  var map,geocoder, marker;
  var depa
rt,arrivee,ptCheck;
  
  /*initialise google MAP V3*/
  function init() {
	/
*gestion des routes*/
    directionsDisplay = new google.maps.DirectionsRendere
r();
	/*emplacement par d�faut de la carte (j'ai mis Paris)*/
    var maison =
 new google.maps.LatLng(48.873818, 2.29498386);
	/*option par d�faut de la cart
e*/
    var myOptions = {
      zoom:6,
      mapTypeId: google.maps.MapTypeI
d.ROADMAP,
      center: maison
    }
	/*creation de la map*/
    map = new 
google.maps.Map(document.getElementById(&quot;divMap&quot;), myOptions);
	/*con
nexion de la map + le panneau de l'itin�raire*/
    directionsDisplay.setMap(ma
p);
    directionsDisplay.setPanel(document.getElementById(&quot;divRoute&quot;
));
	/*intialise le geocoder pour localiser les adresses */
	geocoder = new go
ogle.maps.Geocoder();
	}
  
  
  function trouveRoute() {
  /*test si les v
ariables sont bien initialis�s*/
	if (depart &amp;&amp; arrivee)
	{
	/*mode d
e transport*/
	var choixMode = document.getElementById(&quot;mode&quot;).value;

	
    var request = {
        origin:depart, 
        destination:arrivee,

        travelMode: google.maps.DirectionsTravelMode[choixMode]
    };
	/*app
el � l'API pour tracer l'itin�raire*/
    directionsService.route(request, func
tion(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {

        directionsDisplay.setDirections(response);
      }
    });
	}
  }

  
  function rechercher(src,code)
  {
    ptCheck = code; /*adresse de d�pa
rt ou arriv�e ? */
	if (geocoder) {
	  geocoder.geocode( { 'address': document
.getElementById(src).value}, function(results, status) {
		if (status == google
.maps.GeocoderStatus.OK) {
		 
		  /*ajoute un marqueur � l'adresse choisie*/

		  map.setCenter(results[0].geometry.location);
		  if (marker) { marker.setM
ap(null);}
		  marker = new google.maps.Marker({
			  map: map, 			  
			  po
sition: results[0].geometry.location
		  });
		  /*on remplace l'adresse par c
elle fournie du geocoder*/
		  document.getElementById(src).value = results[0].
formatted_address;
		  if (ptCheck)
		  {
		  depart = results[0].formatted_a
ddress;
		  } else
		  {
		  arrivee = results[0].formatted_address;
		  }

		  /*trace la route*/
		  trouveRoute();
		} else {
		  alert(&quot;Geocode 
n'a rien trouv� !\n raison : &quot; + status);
		}
	  });
	}
	
  }
  

&
lt;/script&gt; 
&lt;/head&gt; 
&lt;body onload=&quot;init();&quot;&gt; 
&lt;d
iv&gt; 
&lt;table&gt;
&lt;tr&gt;&lt;td&gt;&lt;b&gt;d�part: &lt;/b&gt;&lt;/td&g
t;
&lt;td&gt;&lt;input type=&quot;text&quot; id=&quot;adrDep&quot; value=&quot;
&quot; style=&quot;width:300px;&quot;&gt;&lt;/td&gt;
&lt;td&gt;&lt;input type=&
quot;button&quot; value=&quot;recherche&quot; onclick=&quot;rechercher('adrDep',
true)&quot;&gt;&lt;/td&gt;
&lt;td rowspan=&quot;2&quot;&gt;
&lt;b&gt;Transport
: &lt;/b&gt; 
&lt;select id=&quot;mode&quot; onchange=&quot;calcRoute();&quot;&
gt; 
  &lt;option value=&quot;DRIVING&quot;&gt;voiture&lt;/option&gt;
  &lt;op
tion value=&quot;WALKING&quot;&gt;marche&lt;/option&gt;
  &lt;option value=&quo
t;BICYCLING&quot;&gt;v�lo&lt;/option&gt;
&lt;/select&gt;&lt;/td&gt;&lt;/tr&gt;

&lt;tr&gt;&lt;td&gt;&lt;b&gt;arriv�e: &lt;/b&gt;&lt;/td&gt;&lt;td&gt;&lt;input 
type=&quot;text&quot; id=&quot;adrArr&quot; value=&quot;&quot; style=&quot;width
:300px;&quot;&gt;&lt;/td&gt;&lt;td&gt;&lt;input type=&quot;button&quot; value=&q
uot;recherche&quot; onclick=&quot;rechercher('adrArr',false)&quot;&gt;&lt;/td&gt
;&lt;/tr&gt;
&lt;/table&gt;
&lt;/div&gt; 
&lt;div id=&quot;divMap&quot; style
=&quot;float:left;width:70%; height:80%&quot;&gt;&lt;/div&gt; 
&lt;div id=&quot
;divRoute&quot; style=&quot;float:right;width:30%;height 80%&quot;&gt;&lt;/div&g
t; 
&lt;br/&gt;
&lt;center&gt;
&lt;div style=&quot;font-family:Tahoma;font-si
ze:9px&quot;&gt;derni�re mise � jour sur mon site : &lt;a href=&quot;<a href='ht
tp://www.crew.free.fr' target='_blank'>http://www.crew.free.fr</a>&quot;&gt;<a h
ref='http://www.crew.free.fr&lt;/a&gt;&lt;br&gt;powered' target='_blank'>http://
www.crew.free.fr&lt;/a&gt;&lt;br&gt;powered</a> by &lt;b&gt;AmRouNiX&lt;/b&gt; /
 &lt;b&gt;MaSTeR-KiLLeR&lt;/b&gt; (&lt;i&gt;A. Selim&lt;/i&gt;) &lt;br&gt; Toute
s copies autoris�es !&lt;/div&gt;
&lt;/center&gt;
&lt;/body&gt; 
&lt;/html&gt
;
</pre>
